/*
 * @Author: yangzh
 * @Date: 2021-01-07 11:32:51
 * @LastEditTime: 2021-01-19 17:28:30
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \agcimViewer\src\widgets\SunshineCalculation\js\selectWindow.js
 */

class SelectHelpler{
    construct(){}

    getComponents(tileset,type){
        var selectedFeatures = [];
        var tileChildren = tileset.root.children;
        for(let i = 0 ; i < tileChildren.length ; i++){
            if('_features' in tileChildren[i].content && tileChildren[i].content._features){
                for(let j = 0 ; j < tileChildren[i].content._features.length ; j++){
                    let feature = tileChildren[i].content.getFeature(j);
                    let selectFeature = {};
                    let featureId = feature.getProperty("name");
                    let catagory = feature.getProperty("catagory");
                    if (catagory == type) {
                        selectFeature.id = featureId;
                        // selectFeature.color = feature.color;
                        selectFeature.object = feature;
                        selectFeature.modelMatrix = feature.tileset.root.computedTransform;
                        // selectFeature.batchId = feature._batchId;
                        // feature.color = Cesium.Color.RED;
                        selectedFeatures.push(selectFeature);
                    }
                }
            }else{
                if('_contents' in tileChildren[i]._content && tileChildren[i]._content._contents){
                    for(let k = 0 ; k < tileChildren[i]._content._contents.length ; k++){
                        if('_features' in tileChildren[i]._content._contents[k] && tileChildren[i]._content._contents[k]._features){
                            for(let l = 0 ; l < tileChildren[i]._content._contents[k]._features.length ; l++){
                                let feature = tileChildren[i]._content._contents[k].getFeature(l);
                                let selectFeature = {};
                                let featureId = feature.getProperty("name");
                                let catagory = feature.getProperty("catagory");
                                if (catagory == type) {
                                    selectFeature.id = featureId;
                                    // selectFeature.color = feature.color;
                                    selectFeature.object = feature;
                                    selectFeature.modelMatrix = feature.tileset.root.computedTransform;
                                    // selectFeature.batchId = feature._batchId;
                                    // feature.color = Cesium.Color.RED;
                                    selectedFeatures.push(selectFeature);
                                }
                            }
                        }
                    }
                }
            }
        }
        var heightStyle = new Cesium.Cesium3DTileStyle({
            color : {
                conditions : [
                    ['${catagory} === "幕墙嵌板"', 'rgb(255, 0, 0)'],
                    ['true', 'rgb(255, 255, 255)']
                ]
            }
        });
        tileset.style = heightStyle;
        return selectedFeatures;
    }

}

export default new SelectHelpler();
