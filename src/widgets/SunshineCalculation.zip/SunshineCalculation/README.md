<!--
 * @Author: your name
 * @Date: 2021-01-21 09:15:25
 * @LastEditTime: 2021-01-21 09:24:14
 * @LastEditors: your name
 * @Description: In User Settings Edit
 * @FilePath: \agcimViewer\src\widgets\SunshineCalculation\README.md
-->
## 名称
日照计算

## 英文名
SunshineCalculation

## 缩略图
![](./logo.png)

## 版本
前端：v1.0.2

后台：v1.0.0 

## 描述
提供对建筑窗户、建筑外立面、场地等场景的采光日照时长计算


## 数据规范要求
暂无


## 后台接口
/agsupport-data-manager/agsupport-rest/BIM/dentitya/find?${sql}


## 扩展
修订：shan 2020/11/17
